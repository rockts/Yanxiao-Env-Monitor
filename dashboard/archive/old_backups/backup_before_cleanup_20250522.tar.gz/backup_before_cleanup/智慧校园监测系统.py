#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
智慧校园环境监测系统 - 统一启动器
提供一个图形化界面让用户选择启动哪个版本的仪表盘
"""

import os
import sys
import platform
import tkinter as tk
from tkinter import ttk, messagebox
import subprocess
from                 script_path = PROJECT_ROOT / "真完整版启动.py"
                # 使用系统检测到的Python解释器
                subprocess.Popen(
                    [sys.executable, str(script_path)],
                    creationflags=subprocess.CREATE_NEW_CONSOLE if platform.system() == "Windows" else 0
                )ib import Path

# 获取脚本所在路径
SCRIPT_PATH = Path(__file__).resolve()
PROJECT_ROOT = SCRIPT_PATH.parent

class DashboardLauncher:
    """仪表盘启动器GUI"""
    
    def __init__(self, root):
        self.root = root
        self.setup_ui()
        
    def setup_ui(self):
        """设置UI界面"""
        self.root.title("智慧校园环境监测系统 - 启动器")
        self.root.geometry("600x500")
        self.root.resizable(True, True)
        
        # 设置样式
        self.style = ttk.Style()
        self.style.configure("TButton", font=("微软雅黑", 12))
        self.style.configure("TLabel", font=("微软雅黑", 12))
        self.style.configure("Header.TLabel", font=("微软雅黑", 16, "bold"))
        self.style.configure("Title.TLabel", font=("微软雅黑", 20, "bold"))
        
        # 创建主框架
        main_frame = ttk.Frame(self.root, padding="20")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # 标题
        title_label = ttk.Label(
            main_frame, 
            text="烟铺小学智慧校园环境监测系统", 
            style="Title.TLabel"
        )
        title_label.pack(pady=(0, 20))
        
        # 完整版启动按钮（带图标和说明）
        self.create_launch_button(
            main_frame,
            "启动真·完整版仪表盘",
            "显示所有传感器数据、图表和监控画面",
            self.launch_full_dashboard,
            bg_color="#e6f7ff",
            is_primary=True
        )
        
        # 简化版启动按钮
        self.create_launch_button(
            main_frame,
            "启动简化版仪表盘",
            "仅显示基本传感器数据，适合低配置设备",
            self.launch_simple_dashboard,
            bg_color="#f2f2f2"
        )
        
        # 添加工具按钮区域
        tools_frame = ttk.LabelFrame(main_frame, text="工具", padding="10")
        tools_frame.pack(fill=tk.X, pady=10)
        
        # 添加诊断工具按钮
        diag_btn = ttk.Button(
            tools_frame, 
            text="运行系统诊断", 
            command=self.run_diagnostics
        )
        diag_btn.pack(fill=tk.X, pady=5)
        
        # 添加配置优化按钮
        config_btn = ttk.Button(
            tools_frame, 
            text="优化配置文件", 
            command=self.optimize_config
        )
        config_btn.pack(fill=tk.X, pady=5)
        
        # 添加帮助按钮
        help_btn = ttk.Button(
            tools_frame, 
            text="查看使用说明", 
            command=self.show_help
        )
        help_btn.pack(fill=tk.X, pady=5)
        
        # 状态信息
        self.status_var = tk.StringVar(value="准备就绪")
        status_label = ttk.Label(main_frame, textvariable=self.status_var)
        status_label.pack(pady=10)
        
        # 版本信息
        version_label = ttk.Label(
            main_frame, 
            text="版本 1.0.0 | 智慧校园环境监测系统 © 2025",
            font=("微软雅黑", 8)
        )
        version_label.pack(side=tk.BOTTOM, pady=5)
    
    def create_launch_button(self, parent, title, description, command, bg_color="#ffffff", is_primary=False):
        """创建一个带有标题和描述的启动按钮"""
        # 使用Frame而不是LabelFrame，以便自定义外观
        frame = tk.Frame(parent, bg=bg_color, bd=1, relief=tk.RAISED)
        frame.pack(fill=tk.X, pady=10, ipady=5)
        
        # 标题
        title_label = tk.Label(
            frame, 
            text=title, 
            font=("微软雅黑", 14, "bold"),
            bg=bg_color
        )
        title_label.pack(anchor=tk.W, padx=10, pady=(10, 5))
        
        # 描述
        desc_label = tk.Label(
            frame, 
            text=description,
            font=("微软雅黑", 10),
            bg=bg_color,
            wraplength=550,
            justify=tk.LEFT
        )
        desc_label.pack(anchor=tk.W, padx=10, pady=(0, 10))
        
        # 启动按钮
        button_text = "启动" if not is_primary else "✨ 启动 ✨"
        button = tk.Button(
            frame,
            text=button_text,
            font=("微软雅黑", 12, "bold"),
            bg="#4CAF50" if is_primary else "#e0e0e0",
            fg="white" if is_primary else "black",
            command=command,
            padx=20, 
            pady=5
        )
        button.pack(side=tk.RIGHT, padx=10, pady=10)
        
        return frame
    
    def launch_full_dashboard(self):
        """启动完整版仪表盘"""
        self.status_var.set("正在启动完整版仪表盘...")
        self.root.update()
        
        try:
            if platform.system() == "Darwin":  # macOS
                script_path = PROJECT_ROOT / "真完整版启动.command"
                # 使用AppleScript启动终端
                os.system(f'osascript -e \'tell application "Terminal" to do script "cd {PROJECT_ROOT} && {script_path}"\'')
            else:
                script_path = PROJECT_ROOT / "真完整版启动.py"
                # 确保使用Python3运行
                python_cmd = "python3" if os.system("python3 --version > /dev/null 2>&1") == 0 else sys.executable
                
                if platform.system() == "Windows":
                    subprocess.Popen(
                        [python_cmd, str(script_path)],
                        creationflags=subprocess.CREATE_NEW_CONSOLE
                    )
                else:
                    subprocess.Popen(
                        [python_cmd, str(script_path)]
                    )
            
            self.status_var.set("已启动完整版仪表盘")
            messagebox.showinfo("启动成功", "完整版仪表盘已启动！\n请查看新打开的窗口。")
        except Exception as e:
            self.status_var.set(f"启动失败: {str(e)}")
            messagebox.showerror("启动失败", f"启动完整版仪表盘时出错:\n{str(e)}")
    
    def launch_simple_dashboard(self):
        """启动简化版仪表盘"""
        self.status_var.set("正在启动简化版仪表盘...")
        self.root.update()
        
        try:
            script_path = PROJECT_ROOT / "超级简单版仪表盘.py"
            if platform.system() == "Darwin":  # macOS
                # 使用AppleScript启动终端
                os.system(f'osascript -e \'tell application "Terminal" to do script "cd {PROJECT_ROOT} && python3 {script_path}"\'')
            else:
                subprocess.Popen(
                    [sys.executable, str(script_path)],
                    creationflags=subprocess.CREATE_NEW_CONSOLE if platform.system() == "Windows" else 0
                )
            
            self.status_var.set("已启动简化版仪表盘")
            messagebox.showinfo("启动成功", "简化版仪表盘已启动！\n请查看新打开的窗口。")
        except Exception as e:
            self.status_var.set(f"启动失败: {str(e)}")
            messagebox.showerror("启动失败", f"启动简化版仪表盘时出错:\n{str(e)}")
    
    def run_diagnostics(self):
        """运行系统诊断"""
        self.status_var.set("正在启动系统诊断...")
        self.root.update()
        
        try:
            if platform.system() == "Darwin":  # macOS
                script_path = PROJECT_ROOT / "仪表盘诊断.command"
                # 使用AppleScript启动终端
                os.system(f'osascript -e \'tell application "Terminal" to do script "cd {PROJECT_ROOT} && {script_path}"\'')
            else:
                script_path = PROJECT_ROOT / "仪表盘诊断.py"
                subprocess.Popen(
                    [sys.executable, str(script_path)],
                    creationflags=subprocess.CREATE_NEW_CONSOLE if platform.system() == "Windows" else 0
                )
            
            self.status_var.set("已启动系统诊断")
        except Exception as e:
            self.status_var.set(f"启动诊断失败: {str(e)}")
            messagebox.showerror("启动失败", f"启动系统诊断时出错:\n{str(e)}")
    
    def optimize_config(self):
        """优化配置文件"""
        self.status_var.set("正在优化配置文件...")
        self.root.update()
        
        config_optimizer = PROJECT_ROOT / "配置文件优化.py"
        
        if not config_optimizer.exists():
            messagebox.showerror("错误", "找不到配置文件优化工具!\n请确保'配置文件优化.py'文件存在于项目根目录。")
            self.status_var.set("配置优化失败: 找不到工具")
            return
        
        try:
            if platform.system() == "Darwin":  # macOS
                # 使用AppleScript启动终端
                os.system(f'osascript -e \'tell application "Terminal" to do script "cd {PROJECT_ROOT} && python3 {config_optimizer}"\'')
            else:
                subprocess.Popen(
                    [sys.executable, str(config_optimizer)],
                    creationflags=subprocess.CREATE_NEW_CONSOLE if platform.system() == "Windows" else 0
                )
            
            self.status_var.set("配置文件优化工具已启动")
            messagebox.showinfo("优化工具启动", "配置文件优化工具已启动!\n请在新窗口中完成配置优化。")
        except Exception as e:
            self.status_var.set(f"配置优化失败: {str(e)}")
            messagebox.showerror("启动失败", f"启动配置文件优化工具时出错:\n{str(e)}")
    
    def show_help(self):
        """显示帮助信息"""
        help_file = PROJECT_ROOT / "使用说明.md"
        
        if not help_file.exists():
            help_text = "智慧校园环境监测系统使用说明：\n\n" + \
                      "1. 点击"启动真·完整版仪表盘"按钮启动完整功能的仪表盘\n" + \
                      "2. 点击"启动简化版仪表盘"按钮启动简化版仪表盘\n" + \
                      "3. 如果遇到问题，请使用"运行系统诊断"工具\n\n" + \
                      "详细说明请查看项目目录中的使用说明.md文件"
            messagebox.showinfo("使用说明", help_text)
            return
        
        # 尝试使用系统默认应用打开MD文件
        try:
            if platform.system() == "Darwin":  # macOS
                subprocess.Popen(["open", str(help_file)])
            elif platform.system() == "Windows":
                os.startfile(str(help_file))
            else:  # Linux
                subprocess.Popen(["xdg-open", str(help_file)])
                
            self.status_var.set("已打开使用说明")
        except Exception as e:
            # 如果无法打开，则显示简单的帮助信息
            help_text = "智慧校园环境监测系统使用说明：\n\n" + \
                      "1. 点击"启动真·完整版仪表盘"按钮启动完整功能的仪表盘\n" + \
                      "2. 点击"启动简化版仪表盘"按钮启动简化版仪表盘\n" + \
                      "3. 如果遇到问题，请使用"运行系统诊断"工具\n\n" + \
                      f"无法自动打开说明文件，请手动打开：{help_file}"
            messagebox.showinfo("使用说明", help_text)
            self.status_var.set(f"打开说明失败: {str(e)}")

def main():
    """主函数"""
    try:
        import tkinter as tk
    except ImportError:
        print("错误: 无法导入tkinter库，请确保您已安装Python的tkinter包。")
        sys.exit(1)
    
    root = tk.Tk()
    app = DashboardLauncher(root)
    
    # 设置窗口图标（如果有）
    icon_path = PROJECT_ROOT / "assets" / "icon.png"
    if icon_path.exists():
        try:
            from PIL import Image, ImageTk
            icon = ImageTk.PhotoImage(Image.open(icon_path))
            root.iconphoto(True, icon)
        except ImportError:
            pass
    
    # 启动应用
    root.mainloop()

if __name__ == "__main__":
    main()
